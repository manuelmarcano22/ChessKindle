pgn2latex is a simple python script for converting chess games to formatted Latex code.

It needs three files:
1) The python script pgn2latex.py
2) A Latex file pgn2latex.tex
3) A pgn file pgn2latex_in.pgn

Requirements:

Python 3 with:
shlex
chess
unicodedata
StringIO
(use pip install <packagename> in Ubuntu)

Latex with:
KOMA
texmate
needspace
xskak
fmtcount
inputenc
multicol
imakeidx
scrlayer-scrpage
hyperref
(installing texlive-full should do the job in Ubuntu)

Usage:
Copy a chess game in pgn format into the file pgn2latex_in.pgn and execute the python script pgn2latex.py in the very folder (i.e. cd to the directory first).
The script then creates a file pgn2latex_out.tex.
Open the file pgn2latex.tex with a Latex editor of your choice (or use a terminal) and execute it.
This will create a file pgn2latex.pdf. That's it.

Notes:
You can use \sp, \sn, \sb, \sr, \sq and \sk in pgn comments to print piece symbols for pawn, knight, bishop, rook, queen and king. You can also use other Latex commands. However, be careful not to add lose { or } brackets, they will break the output. Also make sure that your chess software accepts comments with { or }.
You can also add Diagrams in ChessBase (i.e. {Diagram #}) or ChessAssistant format, even in side lines. There is sometimes a positioning problem in ChessAssistant format, since the script expects the diagram marker after the move the diagram should be displayed at. For adding a diagram, you can also add DiaW# (without any space behind or in front) to (usually the beginning or end of) a comment. For a diagram from black's side of view (an inverse board), add DiaB#.
If there is more than one variation, the script adds an enumeration using a) b) ... and so on. If a variation has several sub-variations, it adds a1) a2) and so on. Do not use too many levels (sub-sub-sub-sub... variations), the script crashes with more than 9 levels (which will also drive your readers crazy).
For positions (not games) just enter Event and White (for instance: Event "rook endings" and White "Lucena position").
The script tries to be flexible, but I cannot test any possible game and it will crash in some cases I just didn't think of. If you experience a crash with a pgn-conform game, feel free to email to kling #at~ rybkachess.com.

